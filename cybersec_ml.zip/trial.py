# ==== preprocess input ====
# def preprocess_input(data, model_type='ml', json_to_feature=None):
#     """
#     preprocess raw JSON for te models
#     fits missing columns and applies selector and scaler
#     """
#     # Convert single dict to list
#     if isinstance(data, dict):
#         df = pd.DataFrame([data])
#     elif isinstance(data, list):
#         df = pd.DataFrame(data)
#     else:
#         raise ValueError("Input data must be dict or list of dicts")
#
#     # mapping user-friendly JSON keys to training feature names
#     if json_to_feature:
#         for key, value in json_to_feature.items():
#             if key in df.columns:
#                 df[value] = df.pop(key)
#
#     # Add missing columns with 0
#     for col in feature_columns:
#         if col not in df.columns:
#             df[col] = 0
#
#     # Reorder columns exactly as in training
#     df = df[feature_columns]
#
#     # Force numeric, replace inf/nan
#     df = df.apply(pd.to_numeric, errors='coerce').replace([np.inf, -np.inf], 0).fillna(0)
#
#     if model_type == 'ml':
#         # ML: selector + scaler
#         X_selected = selector.transform(df)  # DataFrame with exact column names
#         X_scaled = scaler.transform(X_selected)  # NumPy array
#         return X_scaled
#     else:
#         # DL: reshape to (N, n_features, 1)
#         return df.values[..., np.newaxis]


# def predict_ml(model_name):
#     if model_name not in ml_models:
#         return jsonify({'error': f'Model {model_name} not found'}), 404
#
#     data = request.get_json()
#     if not data:
#         return jsonify({'error': 'No data received'}), 400
#
#     try:
#         # Optional: define friendly-to-training feature mapping
#         json_to_feature = {
#             "Src_Port": "Src Port",
#             "Dst_Port": "Dst Port",
#             "Flow_Duration": "Flow Duration",
#         }
#
#         X = preprocess_input(data, model_type='ml', json_to_feature=json_to_feature)
#         y_pred = ml_models[model_name].predict(X)
#         y_probs = ml_models[model_name].predict_proba(X) if hasattr(ml_models[model_name], "predict_proba") else None
#         label_pred = encoder.inverse_transform(y_pred)
#
#         # Single row vs batch
#         if len(label_pred) == 1:
#             label_pred = label_pred[0]
#             y_probs = y_probs[0].tolist() if y_probs is not None else None
#         else:
#             label_pred = label_pred.tolist()
#             y_probs = y_probs.tolist() if y_probs is not None else None
#
#         result = {'predicted_label': label_pred}
#         if y_probs is not None:
#             result['probabilities'] = y_probs
#
#         return jsonify(result), 200
#
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500